import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Services from "@/components/Services";
import Experience from "@/components/Experience";
import Portfolio from "@/components/Portfolio";
import Tools from "@/components/Tools";
import Pricing from "@/components/Pricing";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import PdfGenerator from "@/components/PdfGenerator";
import { defaultUserData, UserData } from "@/lib/utils";
import { Helmet } from "react-helmet";

const Home = () => {
  const [userData] = useState<UserData>(defaultUserData);
  const { contentRef, generatePdf } = PdfGenerator({ userData });

  return (
    <>
      <Helmet>
        <title>{userData.name} | Virtual Assistant Portfolio</title>
        <meta name="description" content="Professional virtual assistant services by {userData.name}. Providing email management, scheduling, and administrative support for businesses." />
      </Helmet>
      
      <Navbar userData={userData} />
      
      <main ref={contentRef}>
        <Hero userData={userData} />
        <About userData={userData} />
        <Services />
        <Experience userData={userData} />
        <Portfolio />
        <Tools />
        <Pricing />
        <Contact userData={userData} />
      </main>
      
      <Footer userData={userData} onDownloadPdf={generatePdf} />
    </>
  );
};

export default Home;
