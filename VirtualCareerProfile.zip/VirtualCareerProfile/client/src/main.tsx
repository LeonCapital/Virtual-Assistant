import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import AOS from 'aos';
import 'aos/dist/aos.css';

// Add custom CSS variables for the VA portfolio
const style = document.createElement('style');
style.textContent = `
  :root {
    --background: 0 0% 100%;
    --foreground: 20 14.3% 4.1%;
    --muted: 60 4.8% 95.9%;
    --muted-foreground: 25 5.3% 44.7%;
    --popover: 0 0% 100%;
    --popover-foreground: 20 14.3% 4.1%;
    --card: 0 0% 100%;
    --card-foreground: 20 14.3% 4.1%;
    --border: 20 5.9% 90%;
    --input: 20 5.9% 90%;
    --primary: 210 76% 47%;
    --primary-foreground: 211 100% 99%;
    --secondary: 215 67% 58%;
    --secondary-foreground: 24 9.8% 10%;
    --accent: 16 94% 69%;
    --accent-foreground: 24 9.8% 10%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 60 9.1% 97.8%;
    --ring: 20 14.3% 4.1%;
    --radius: 0.5rem;
    --chart-1: 210 76% 47%;
    --chart-2: 220 76% 40%;
    --chart-3: 16 94% 69%;
    --chart-4: 16 80% 60%;
    --chart-5: 220 60% 60%;
  }
  
  .dark {
    --background: 240 10% 3.9%;
    --foreground: 0 0% 98%;
    --muted: 240 3.7% 15.9%;
    --muted-foreground: 240 5% 64.9%;
    --popover: 240 10% 3.9%;
    --popover-foreground: 0 0% 98%;
    --card: 240 10% 3.9%;
    --card-foreground: 0 0% 98%;
    --border: 240 3.7% 15.9%;
    --input: 240 3.7% 15.9%;
    --primary: 210 76% 47%;
    --primary-foreground: 211 100% 99%;
    --secondary: 215 67% 58%;
    --secondary-foreground: 0 0% 98%;
    --accent: 16 94% 69%;
    --accent-foreground: 0 0% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 0 0% 98%;
    --ring: 240 4.9% 83.9%;
  }
  
  html {
    scroll-behavior: smooth;
  }
  
  section {
    scroll-margin-top: 80px;
  }
  
  body {
    font-family: 'Open Sans', sans-serif;
  }
  
  h1, h2, h3, h4, h5, h6 {
    font-family: 'Montserrat', sans-serif;
  }
  
  .shadow-custom {
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  }
`;

document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
