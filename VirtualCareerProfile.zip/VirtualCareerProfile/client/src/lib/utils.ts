import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface UserData {
  name: string;
  email: string;
  phone: string;
}

export const defaultUserData: UserData = {
  name: "Peter Mburu",
  email: "petermburu818@gmail.com",
  phone: "+254757541361"
};

export interface Service {
  icon: string;
  title: string;
  description: string;
  level: string;
  rating: number;
}

export const services: Service[] = [
  {
    icon: "fa-envelope",
    title: "Email Management",
    description: "Inbox organization, filtering, drafting responses, and follow-ups to keep your communication flowing smoothly.",
    level: "Expert Level",
    rating: 5
  },
  {
    icon: "fa-calendar-alt",
    title: "Calendar Management",
    description: "Appointment scheduling, meeting coordination, reminders, and preventing scheduling conflicts.",
    level: "Expert Level",
    rating: 5
  },
  {
    icon: "fa-tasks",
    title: "Project Management",
    description: "Task organization, progress tracking, deadline management, and team coordination.",
    level: "Advanced Level",
    rating: 4
  },
  {
    icon: "fa-hashtag",
    title: "Social Media Management",
    description: "Content scheduling, audience engagement, analytics monitoring, and platform optimization.",
    level: "Advanced Level",
    rating: 4
  },
  {
    icon: "fa-file-alt",
    title: "Document Preparation",
    description: "Creating, formatting, and editing documents, presentations, spreadsheets, and reports.",
    level: "Expert Level",
    rating: 5
  },
  {
    icon: "fa-headset",
    title: "Customer Support",
    description: "Responding to inquiries, resolving issues, and maintaining positive client relationships.",
    level: "Advanced Level",
    rating: 4
  }
];

export interface Experience {
  title: string;
  company: string;
  period: string;
  description: string;
  achievements: string[];
}

export const experiences: Experience[] = [
  {
    title: "Virtual Executive Assistant",
    company: "SkyRocket Consulting",
    period: "2020 - Present",
    description: "Providing comprehensive administrative support to the CEO and executive team, managing complex schedules, coordinating international travel, and handling sensitive communications.",
    achievements: [
      "Reduced email response time by 68% through inbox management system",
      "Coordinated 12+ international business trips annually",
      "Implemented new filing system saving 5+ hours weekly"
    ]
  },
  {
    title: "Social Media Manager",
    company: "GrowthDigital Agency",
    period: "2018 - 2020",
    description: "Managed social media accounts for 8 clients across multiple industries, creating content calendars, scheduling posts, and analyzing performance metrics.",
    achievements: [
      "Increased client engagement by average of 42%",
      "Created 200+ pieces of content monthly across platforms",
      "Developed reporting dashboard for streamlined client updates"
    ]
  },
  {
    title: "Administrative Assistant",
    company: "Summit Financial Group",
    period: "2016 - 2018",
    description: "Supported a team of financial advisors with client communications, document preparation, calendar management, and CRM updates.",
    achievements: [
      "Managed scheduling for 6 advisors with 20+ weekly appointments",
      "Prepared 15+ client presentations weekly",
      "Implemented new CRM system and trained team on usage"
    ]
  },
  {
    title: "Project Coordinator",
    company: "InnovateTech Solutions",
    period: "2014 - 2016",
    description: "Assisted project managers with documentation, client communications, and team coordination for software implementation projects.",
    achievements: [
      "Coordinated 4 simultaneous projects with cross-functional teams",
      "Maintained detailed project documentation and status reports",
      "Reduced meeting time by 25% through improved agenda management"
    ]
  }
];

export interface Testimonial {
  text: string;
  author: string;
  company: string;
}

export const testimonials: Testimonial[] = [
  {
    text: "Working with Peter Mburu has been transformational for my business. His organizational skills and attention to detail have freed up hours of my time each week, allowing me to focus on growth and client relationships. I couldn't recommend him more highly!",
    author: "Sarah Johnson",
    company: "CEO, Bright Marketing"
  },
  {
    text: "Peter Mburu has been an exceptional addition to our team. His email management and customer support skills have significantly improved our client satisfaction rates. He's proactive, detail-oriented, and incredibly reliable.",
    author: "Michael Rodriguez",
    company: "Founder, Rodriguez Consulting"
  },
  {
    text: "I was drowning in administrative tasks before finding Peter Mburu. His ability to organize my chaotic schedule and streamline my processes has been invaluable. He's responsive, efficient, and has become an essential part of my business.",
    author: "Jennifer Lee",
    company: "Independent Consultant"
  }
];

export interface PortfolioItem {
  image: string;
  title: string;
  description: string;
  category: string;
  id: string;
}

export const portfolioItems: PortfolioItem[] = [
  {
    image: "https://images.unsplash.com/photo-1633265486501-0cf524a07213?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Email Campaign Management",
    description: "Designed and managed a 6-part email nurture sequence for a client's product launch, resulting in a 32% open rate and 8% conversion rate.",
    category: "Email Marketing",
    id: "email-campaign"
  },
  {
    image: "https://images.unsplash.com/photo-1600267204091-5c1ab8b10c02?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Calendar System Overhaul",
    description: "Implemented a new scheduling system for a consultant, reducing booking errors by 98% and increasing client satisfaction.",
    category: "Productivity",
    id: "calendar-system"
  },
  {
    image: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Social Media Content Calendar",
    description: "Created a 3-month content calendar for a retail client, increasing engagement by 47% and followers by 28%.",
    category: "Social Media",
    id: "social-media"
  },
  {
    image: "https://images.unsplash.com/photo-1487528278747-ba99ed528ebc?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Client Onboarding System",
    description: "Developed a streamlined onboarding process for a coaching business, reducing onboarding time by 65% and improving client experience.",
    category: "Systems & Processes",
    id: "onboarding-system"
  },
  {
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Financial Report Templates",
    description: "Created custom financial reporting templates for a small business, saving 10+ hours monthly and improving financial clarity.",
    category: "Document Preparation",
    id: "report-templates"
  },
  {
    image: "https://images.unsplash.com/photo-1560472355-536de3962603?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    title: "Customer Service Protocol",
    description: "Implemented a customer service protocol for an e-commerce business, reducing response time by 76% and increasing satisfaction scores.",
    category: "Customer Support",
    id: "customer-service"
  }
];

export interface Tool {
  icon: string;
  name: string;
  level: string;
}

export const mainTools: Tool[] = [
  { icon: "fa-google", name: "Google Workspace", level: "Expert Level" },
  { icon: "fa-slack", name: "Slack", level: "Expert Level" },
  { icon: "fa-trello", name: "Trello", level: "Expert Level" },
  { icon: "fa-tasks", name: "Asana", level: "Advanced Level" },
  { icon: "fa-mailchimp", name: "Mailchimp", level: "Expert Level" },
  { icon: "fa-wordpress", name: "WordPress", level: "Advanced Level" },
  { icon: "fa-pen-fancy", name: "Canva", level: "Expert Level" },
  { icon: "fa-calendar-check", name: "Calendly", level: "Expert Level" }
];

export const productivityTools = [
  "Microsoft Office", "Monday.com", "Notion", "Evernote", "ClickUp", "Todoist"
];

export const communicationTools = [
  "Zoom", "Hootsuite", "Buffer", "ConvertKit", "HubSpot", "ActiveCampaign"
];

export interface Package {
  name: string;
  subtitle: string;
  price: string;
  period: string;
  hours: string | null;
  features: { included: boolean; text: string }[];
  popular: boolean;
}

export const packages: Package[] = [
  {
    name: "Basic",
    subtitle: "For small businesses & entrepreneurs",
    price: "$35",
    period: "/hour",
    hours: null,
    features: [
      { included: true, text: "Email management & customer support" },
      { included: true, text: "Calendar management & scheduling" },
      { included: true, text: "Basic document preparation" },
      { included: true, text: "Data entry & research" },
      { included: false, text: "Social media management" },
      { included: false, text: "Project management" }
    ],
    popular: false
  },
  {
    name: "Professional",
    subtitle: "For growing businesses",
    price: "$750",
    period: "/month",
    hours: "20 hours included",
    features: [
      { included: true, text: "All Basic package services" },
      { included: true, text: "Social media management" },
      { included: true, text: "Basic project management" },
      { included: true, text: "Content scheduling" },
      { included: true, text: "Monthly reports & analytics" },
      { included: false, text: "System & process creation" }
    ],
    popular: true
  },
  {
    name: "Executive",
    subtitle: "For established businesses",
    price: "$1,500",
    period: "/month",
    hours: "40 hours included",
    features: [
      { included: true, text: "All Professional package services" },
      { included: true, text: "Advanced project management" },
      { included: true, text: "System & process creation" },
      { included: true, text: "Content creation assistance" },
      { included: true, text: "Complex calendar management" },
      { included: true, text: "Weekly strategy check-ins" }
    ],
    popular: false
  }
];

export interface ContactFormValues {
  name: string;
  email: string;
  subject: string;
  message: string;
}
