import { services } from "@/lib/utils";
import SectionHeader from "./SectionHeader";

const Services = () => {
  return (
    <section id="services" className="py-16 md:py-24 bg-light">
      <div className="container mx-auto px-4">
        <SectionHeader 
          title="Skills & Services Offered" 
          subtitle="Comprehensive virtual assistance to streamline your business operations"
        />
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-custom p-6 hover:shadow-lg transition duration-300 transform hover:-translate-y-1"
            >
              <div className="inline-block p-3 bg-primary/10 rounded-full mb-5">
                <i className={`fas ${service.icon} text-primary text-2xl`}></i>
              </div>
              <h3 className="font-heading font-semibold text-xl mb-3">{service.title}</h3>
              <p className="text-black mb-4">{service.description}</p>
              <div className="flex items-center text-sm text-primary font-medium">
                <span className="mr-2">{service.level}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className={`fas fa-star ${i >= service.rating ? 'far' : ''}`}></i>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl shadow-custom p-8">
          <h3 className="font-heading font-semibold text-2xl mb-5 text-center">Additional Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-pen text-accent mr-3"></i>
              <span>Content Writing</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-chart-bar text-accent mr-3"></i>
              <span>Data Analysis</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-money-bill-wave text-accent mr-3"></i>
              <span>Bookkeeping</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-search text-accent mr-3"></i>
              <span>Research</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-plane text-accent mr-3"></i>
              <span>Travel Planning</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-file-invoice text-accent mr-3"></i>
              <span>Invoicing</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-phone text-accent mr-3"></i>
              <span>Call Handling</span>
            </div>
            <div className="flex items-center p-3 bg-light rounded-lg">
              <i className="fas fa-cogs text-accent mr-3"></i>
              <span>Process Improvement</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
