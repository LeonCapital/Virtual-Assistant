import { useState, useEffect, useCallback } from "react";
import { UserData, experiences, testimonials } from "@/lib/utils";
import SectionHeader from "./SectionHeader";

interface ExperienceProps {
  userData: UserData;
}

const Experience = ({ userData }: ExperienceProps) => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  
  const nextTestimonial = useCallback(() => {
    setActiveTestimonial((prev) => 
      prev === testimonials.length - 1 ? 0 : prev + 1
    );
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (!isPaused) {
        nextTestimonial();
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [isPaused, nextTestimonial]);

  return (
    <section id="experience" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <SectionHeader
          title="Work Experience"
          subtitle="A proven track record of supporting businesses and executives"
        />
        
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {experiences.map((experience, index) => (
            <div key={index} className="relative pl-8 border-l-4 border-primary/30 pb-8">
              <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary"></div>
              <h3 className="font-heading font-semibold text-xl mb-1">{experience.title}</h3>
              <div className="text-accent font-medium mb-2">{experience.company} | {experience.period}</div>
              <p className="text-black mb-4">{experience.description}</p>
              <ul className="space-y-2 text-sm text-black">
                {experience.achievements.map((achievement, i) => (
                  <li key={i} className="flex items-start">
                    <i className="fas fa-check text-accent mt-1 mr-2"></i>
                    <span>{achievement}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h3 className="font-heading font-semibold text-2xl text-primary">Client Testimonials</h3>
            <button 
              className="text-accent hover:text-primary transition-colors" 
              onClick={() => setIsPaused(!isPaused)}
              aria-label={isPaused ? "Resume testimonials" : "Pause testimonials"}
            >
              <i className={`fas ${isPaused ? 'fa-play' : 'fa-pause'} mr-2`}></i>
              {isPaused ? 'Resume' : 'Pause'}
            </button>
          </div>
          
          <div className="testimonial-slider relative overflow-hidden rounded-xl shadow-lg">
            {/* Navigation Arrows */}
            <button 
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-primary w-10 h-10 rounded-full flex items-center justify-center z-10 shadow-md transition-all duration-300"
              onClick={() => {
                setActiveTestimonial(prev => (prev === 0 ? testimonials.length - 1 : prev - 1));
                setIsPaused(true);
              }}
              aria-label="Previous testimonial"
            >
              <i className="fas fa-chevron-left"></i>
            </button>
            
            <button 
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-primary w-10 h-10 rounded-full flex items-center justify-center z-10 shadow-md transition-all duration-300"
              onClick={() => {
                nextTestimonial();
                setIsPaused(true);
              }}
              aria-label="Next testimonial"
            >
              <i className="fas fa-chevron-right"></i>
            </button>
            
            {/* Progress bar */}
            <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-200 z-10">
              <div 
                className="h-full bg-accent transition-all duration-200" 
                style={{ width: `${(activeTestimonial + 1) / testimonials.length * 100}%` }}
              ></div>
            </div>
            
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${activeTestimonial * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div 
                  key={index} 
                  className="w-full flex-shrink-0 px-4 py-8"
                  onMouseEnter={() => setIsPaused(true)}
                  onMouseLeave={() => setIsPaused(false)}
                >
                  <div className="bg-light rounded-xl p-8 shadow-custom relative">
                    <div className="absolute top-0 right-0 transform -translate-y-1/2 translate-x-1/4">
                      <div className="bg-accent text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg">
                        <i className="fas fa-quote-right text-xl"></i>
                      </div>
                    </div>
                    <div className="flex items-center mb-6">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                        <span className="text-2xl font-bold text-primary">{testimonial.author.charAt(0)}</span>
                      </div>
                      <div>
                        <div className="text-primary font-heading font-semibold text-lg">{testimonial.author}</div>
                        <div className="text-black">{testimonial.company}</div>
                      </div>
                    </div>
                    <p className="italic text-black mb-4 text-lg">
                      "{testimonial.text.replace("[Your Name]", userData.name)}"
                    </p>
                    <div className="flex text-accent">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className="fas fa-star mr-1"></i>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex justify-center mt-6 space-x-3">
              {testimonials.map((_, index) => (
                <button 
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    activeTestimonial === index 
                      ? 'bg-primary w-6' 
                      : 'bg-gray-300 hover:bg-primary/50'
                  }`}
                  onClick={() => {
                    setActiveTestimonial(index);
                    setIsPaused(true);
                  }}
                  aria-label={`View testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
