import { useState } from "react";
import { UserData, ContactFormValues } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import SectionHeader from "./SectionHeader";

interface ContactProps {
  userData: UserData;
}

const Contact = ({ userData }: ContactProps) => {
  const { toast } = useToast();
  const [formValues, setFormValues] = useState<ContactFormValues>({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormValues(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!formValues.name || !formValues.email || !formValues.message) {
      toast({
        title: "Error",
        description: "Please fill out all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      await apiRequest("POST", "/api/contact", formValues);
      
      toast({
        title: "Success!",
        description: "Thank you for your message! I will be in touch soon.",
      });
      
      setFormValues({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      toast({
        title: "Something went wrong",
        description: "Your message could not be sent. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <SectionHeader
          title="Get in Touch"
          subtitle="Ready to streamline your business? Let's discuss how I can help!"
        />
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <div className="bg-light rounded-xl p-8 shadow-custom mb-8">
              <h3 className="font-heading font-semibold text-2xl mb-6 text-primary">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <i className="fas fa-envelope text-primary"></i>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Email</h4>
                    <p className="text-primary">{userData.email}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <i className="fas fa-phone text-primary"></i>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Phone</h4>
                    <p className="text-primary">{userData.phone}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <i className="fas fa-clock text-primary"></i>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Availability</h4>
                    <p className="text-black">Monday - Friday, 9am - 5pm EST</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-light rounded-xl p-8 shadow-custom">
              <h3 className="font-heading font-semibold text-2xl mb-6 text-primary">Connect With Me</h3>
              <div className="flex space-x-4">
                <a href="#" className="bg-primary/10 hover:bg-primary/20 text-primary rounded-full p-3 transition duration-300">
                  <i className="fab fa-linkedin-in text-xl"></i>
                </a>
                <a href="#" className="bg-primary/10 hover:bg-primary/20 text-primary rounded-full p-3 transition duration-300">
                  <i className="fab fa-twitter text-xl"></i>
                </a>
                <a href="#" className="bg-primary/10 hover:bg-primary/20 text-primary rounded-full p-3 transition duration-300">
                  <i className="fab fa-facebook-f text-xl"></i>
                </a>
                <a href="#" className="bg-primary/10 hover:bg-primary/20 text-primary rounded-full p-3 transition duration-300">
                  <i className="fab fa-instagram text-xl"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="bg-light rounded-xl p-8 shadow-custom">
            <h3 className="font-heading font-semibold text-2xl mb-6 text-primary">Send a Message</h3>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="name" className="block mb-2 font-medium">Name</label>
                <input 
                  type="text" 
                  id="name" 
                  value={formValues.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50" 
                  placeholder="Your name"
                />
              </div>
              <div>
                <label htmlFor="email" className="block mb-2 font-medium">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  value={formValues.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50" 
                  placeholder="Your email"
                />
              </div>
              <div>
                <label htmlFor="subject" className="block mb-2 font-medium">Subject</label>
                <input 
                  type="text" 
                  id="subject" 
                  value={formValues.subject}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50" 
                  placeholder="Subject"
                />
              </div>
              <div>
                <label htmlFor="message" className="block mb-2 font-medium">Message</label>
                <textarea 
                  id="message" 
                  rows={5}
                  value={formValues.message}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50" 
                  placeholder="Your message"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
        
        <div className="max-w-3xl mx-auto mt-20 text-center">
          <div className="mb-6">
            <i className="fas fa-star text-accent text-3xl"></i>
          </div>
          <h3 className="font-heading font-semibold text-2xl text-primary mb-4">Ready to focus on growing your business?</h3>
          <p className="text-black mb-8">
            Contact <span className="font-medium text-primary">{userData.name}</span> today to discuss how I can help streamline your operations and boost your productivity.
          </p>
          <Button asChild variant="accent">
            <a href="#">Schedule a Free Consultation</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Contact;
