import { UserData } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface HeroProps {
  userData: UserData;
}

const Hero = ({ userData }: HeroProps) => {
  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-primary/5 to-secondary/10">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="font-heading font-bold text-4xl md:text-5xl lg:text-6xl text-primary mb-4">
              {userData.name}
            </h1>
            <h2 className="font-heading text-2xl md:text-3xl text-secondary mb-6">
              Virtual Assistant
            </h2>
            <p className="text-muted text-lg mb-8 leading-relaxed">
              Supporting businesses with expert administrative services, organization solutions, and digital management to help you focus on what matters most.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Button asChild>
                <a href="#contact">Get in Touch</a>
              </Button>
              <Button asChild variant="outline">
                <a href="#services">View Services</a>
              </Button>
            </div>
          </div>
          <div className="flex justify-center md:justify-end">
            <img 
              src="/images/peter-mburu.jpg" 
              alt="Peter Mburu - Virtual Assistant" 
              className="rounded-lg shadow-xl max-w-full h-auto object-cover border-4 border-primary/20"
              width="500" 
              height="500"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
