import { UserData } from "@/lib/utils";
import SectionHeader from "./SectionHeader";

interface AboutProps {
  userData: UserData;
}

const About = ({ userData }: AboutProps) => {
  return (
    <section id="about" className="py-16 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <SectionHeader 
          title="Professional Bio" 
          subtitle="An experienced virtual assistant dedicated to helping you succeed"
        />
        
        <div className="grid md:grid-cols-5 gap-8 items-center">
          <div className="md:col-span-3">
            <p className="text-lg leading-relaxed mb-6">
              <span className="font-semibold text-primary">{userData.name}</span> is a detail-oriented Virtual Assistant with over 7 years of experience supporting entrepreneurs, small businesses, and corporate executives across Kenya and internationally. With a background in business administration and digital marketing from Nairobi University, I specialize in creating efficient systems that save clients time and streamline their operations.
            </p>
            <p className="text-lg leading-relaxed mb-6">
              My mission is to provide exceptional administrative support that allows you to focus on growing your business while I handle the day-to-day operational tasks. I pride myself on my ability to anticipate needs, meet tight deadlines, and maintain clear communication throughout every project, regardless of time zone differences.
            </p>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-light rounded-lg p-5 text-center border-l-4 border-accent">
                <i className="fas fa-calendar-check text-accent text-3xl mb-3"></i>
                <h3 className="font-heading font-medium text-xl mb-1">Reliable</h3>
                <p className="text-black">Meeting deadlines consistently</p>
              </div>
              <div className="bg-light rounded-lg p-5 text-center border-l-4 border-accent">
                <i className="fas fa-bolt text-accent text-3xl mb-3"></i>
                <h3 className="font-heading font-medium text-xl mb-1">Efficient</h3>
                <p className="text-black">Maximizing productivity</p>
              </div>
            </div>
          </div>
          <div className="md:col-span-2">
            <div className="bg-light rounded-xl p-6 shadow-custom">
              <h3 className="font-heading font-semibold text-xl mb-4 text-primary">Professional Snapshot</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>7+ years of VA experience</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>Bachelor's from Nairobi University</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>Google Digital Marketing Certified</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>Proficient in 20+ productivity tools</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>Supported 30+ clients globally</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-accent mt-1 mr-3"></i>
                  <span>Fluent in English and Swahili</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
