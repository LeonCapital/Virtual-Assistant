interface SectionHeaderProps {
  title: string;
  subtitle: string;
}

const SectionHeader = ({ title, subtitle }: SectionHeaderProps) => {
  return (
    <div className="max-w-3xl mx-auto text-center mb-12">
      <h2 className="relative font-heading font-bold text-3xl md:text-4xl mb-6 pb-3 inline-block">
        {title}
        <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-32 h-1.5 bg-accent rounded-full"></span>
      </h2>
      <p className="text-black text-lg">{subtitle}</p>
    </div>
  );
};

export default SectionHeader;