import { useRef } from "react";
import { UserData } from "@/lib/utils";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

interface PdfGeneratorProps {
  userData: UserData;
}

const PdfGenerator = ({ userData }: PdfGeneratorProps) => {
  const contentRef = useRef<HTMLDivElement>(null);

  const generatePdf = async () => {
    if (!contentRef.current) return;

    const pdf = new jsPDF("p", "mm", "a4");
    const elements = contentRef.current.querySelectorAll("section");
    
    // Cover page
    pdf.setFillColor(64, 111, 165); // Primary color
    pdf.rect(0, 0, 210, 297, "F");
    
    pdf.setTextColor(255, 255, 255);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(24);
    pdf.text(`${userData.name}`, 105, 120, { align: "center" });
    
    pdf.setFontSize(18);
    pdf.text("Virtual Assistant", 105, 135, { align: "center" });
    
    pdf.setFontSize(12);
    pdf.setFont("helvetica", "normal");
    pdf.text("Professional Portfolio", 105, 150, { align: "center" });
    
    pdf.setFontSize(10);
    pdf.text(`Email: ${userData.email}`, 105, 170, { align: "center" });
    pdf.text(`Phone: ${userData.phone}`, 105, 180, { align: "center" });
    
    pdf.setFontSize(8);
    pdf.text(`Generated on ${new Date().toDateString()}`, 105, 270, { align: "center" });
    
    // Table of contents
    pdf.addPage();
    pdf.setTextColor(64, 111, 165);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(18);
    pdf.text("Table of Contents", 20, 30);
    
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(12);
    pdf.setTextColor(80, 80, 80);
    
    const sections = [
      "Professional Bio",
      "Skills & Services Offered",
      "Work Experience & Testimonials",
      "Portfolio Samples",
      "Tools & Platforms Proficiency",
      "Pricing & Packages",
      "Contact Information"
    ];
    
    sections.forEach((section, index) => {
      pdf.text(`${index + 1}. ${section}`, 20, 50 + (index * 10));
    });
    
    // Add all sections
    let currentPage = 3;
    
    for (let i = 0; i < elements.length; i++) {
      const element = elements[i];
      
      // Skip contact section for PDF
      if (element.id === "contact") continue;
      
      const canvas = await html2canvas(element, {
        scale: 1,
        useCORS: true,
        allowTaint: true,
        logging: false,
        height: element.scrollHeight,
        windowHeight: element.scrollHeight
      });
      
      const imgData = canvas.toDataURL("image/jpeg", 0.8);
      
      // Calculate how many pages this section will take (roughly)
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      const pageHeight = 297;
      
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addPage();
      
      // Add section header
      const sectionId = element.id;
      let sectionTitle = "";
      
      switch (sectionId) {
        case "about":
          sectionTitle = "Professional Bio";
          break;
        case "services":
          sectionTitle = "Skills & Services Offered";
          break;
        case "experience":
          sectionTitle = "Work Experience & Testimonials";
          break;
        case "portfolio":
          sectionTitle = "Portfolio Samples";
          break;
        case "tools":
          sectionTitle = "Tools & Platforms Proficiency";
          break;
        case "pricing":
          sectionTitle = "Pricing & Packages";
          break;
        default:
          sectionTitle = sectionId.charAt(0).toUpperCase() + sectionId.slice(1);
      }
      
      pdf.setTextColor(64, 111, 165);
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(16);
      pdf.text(sectionTitle, 20, 20);
      
      pdf.addImage(imgData, "JPEG", 0, 30, imgWidth, imgHeight);
      heightLeft -= (pageHeight - 30);
      
      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(
          imgData,
          "JPEG",
          0,
          position,
          imgWidth,
          imgHeight
        );
        heightLeft -= pageHeight;
        currentPage++;
      }
      
      currentPage++;
    }
    
    // Final page with contact info
    pdf.addPage();
    pdf.setFillColor(64, 111, 165);
    pdf.rect(0, 0, 210, 60, "F");
    
    pdf.setTextColor(255, 255, 255);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(20);
    pdf.text("Contact Information", 105, 40, { align: "center" });
    
    pdf.setTextColor(80, 80, 80);
    pdf.setFontSize(14);
    pdf.text(`Name: ${userData.name}`, 20, 80);
    pdf.text(`Email: ${userData.email}`, 20, 95);
    pdf.text(`Phone: ${userData.phone}`, 20, 110);
    
    pdf.setFont("helvetica", "bold");
    pdf.setTextColor(64, 111, 165);
    pdf.text("Availability:", 20, 130);
    
    pdf.setFont("helvetica", "normal");
    pdf.setTextColor(80, 80, 80);
    pdf.text("Monday - Friday, 9am - 5pm EST", 20, 145);
    
    pdf.setFont("helvetica", "bold");
    pdf.setTextColor(64, 111, 165);
    pdf.text("Get in Touch:", 20, 170);
    
    pdf.setFont("helvetica", "normal");
    pdf.setTextColor(80, 80, 80);
    pdf.text("Thank you for reviewing my portfolio. I'd be delighted to discuss", 20, 185);
    pdf.text("how I can help streamline your business operations and save you time.", 20, 200);
    pdf.text("Please contact me to schedule a free consultation.", 20, 215);
    
    // Save the PDF
    pdf.save(`${userData.name.replace(/\s+/g, '_')}_VA_Portfolio.pdf`);
  };

  return {
    contentRef,
    generatePdf
  };
};

export default PdfGenerator;
