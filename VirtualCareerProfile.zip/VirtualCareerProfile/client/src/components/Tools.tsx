import { mainTools, productivityTools, communicationTools } from "@/lib/utils";
import SectionHeader from "./SectionHeader";

const Tools = () => {
  return (
    <section id="tools" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <SectionHeader
          title="Tools & Platforms Proficiency"
          subtitle="The professional tools I use to deliver exceptional results"
        />
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {mainTools.map((tool, index) => (
            <div key={index} className="bg-light rounded-xl p-6 text-center shadow-custom transition duration-300 hover:shadow-lg">
              <i className={`fab ${tool.icon} text-4xl text-primary mb-4`}></i>
              <h3 className="font-heading font-medium text-lg mb-1">{tool.name}</h3>
              <p className="text-sm text-black">{tool.level}</p>
            </div>
          ))}
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-light rounded-xl p-6 shadow-custom">
            <h3 className="font-heading font-semibold text-xl mb-4 text-center text-primary">Productivity & Organization</h3>
            <div className="grid grid-cols-2 gap-4">
              {productivityTools.map((tool, index) => (
                <div key={index} className="flex items-center">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  <span>{tool}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-light rounded-xl p-6 shadow-custom">
            <h3 className="font-heading font-semibold text-xl mb-4 text-center text-primary">Communication & Marketing</h3>
            <div className="grid grid-cols-2 gap-4">
              {communicationTools.map((tool, index) => (
                <div key={index} className="flex items-center">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  <span>{tool}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Tools;
