import { UserData } from "@/lib/utils";

interface FooterProps {
  userData: UserData;
  onDownloadPdf: () => void;
}

const Footer = ({ userData, onDownloadPdf }: FooterProps) => {
  return (
    <footer className="bg-primary text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <span className="font-heading font-bold text-2xl">{userData.name}</span>
              <span className="ml-2 text-accent font-heading text-sm py-1 px-2 rounded-full bg-accent bg-opacity-20">VA</span>
            </div>
            <p className="text-white/80 mb-6">
              Professional virtual assistant services helping businesses streamline operations and boost productivity.
            </p>
            <button 
              onClick={onDownloadPdf}
              className="inline-flex items-center text-white/80 hover:text-white transition cursor-pointer"
            >
              <i className="fas fa-download mr-2"></i>
              <span>Download Portfolio PDF</span>
            </button>
          </div>
          
          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#about" className="text-white/80 hover:text-white transition">About</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">Services</a></li>
              <li><a href="#experience" className="text-white/80 hover:text-white transition">Experience</a></li>
              <li><a href="#portfolio" className="text-white/80 hover:text-white transition">Portfolio</a></li>
              <li><a href="#pricing" className="text-white/80 hover:text-white transition">Pricing</a></li>
              <li><a href="#contact" className="text-white/80 hover:text-white transition">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">Services</h4>
            <ul className="space-y-2">
              <li><a href="#services" className="text-white/80 hover:text-white transition">Email Management</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">Calendar Management</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">Project Management</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">Social Media</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">Customer Support</a></li>
              <li><a href="#services" className="text-white/80 hover:text-white transition">All Services</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/20 pt-6 flex flex-col md:flex-row justify-between items-center">
          <div className="text-white/60 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} {userData.name}. All rights reserved.
          </div>
          <div className="flex space-x-4">
            <a href="#" className="text-white/60 hover:text-white transition">
              <i className="fab fa-linkedin-in"></i>
            </a>
            <a href="#" className="text-white/60 hover:text-white transition">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-white/60 hover:text-white transition">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="text-white/60 hover:text-white transition">
              <i className="fab fa-instagram"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
