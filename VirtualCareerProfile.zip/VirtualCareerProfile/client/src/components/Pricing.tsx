import { packages } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import SectionHeader from "./SectionHeader";

const Pricing = () => {
  return (
    <section id="pricing" className="py-16 md:py-24 bg-primary/5">
      <div className="container mx-auto px-4">
        <SectionHeader
          title="Pricing & Packages"
          subtitle="Flexible options to meet your virtual assistance needs"
        />
        
        <div className="grid md:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-xl shadow-custom overflow-hidden transition duration-300 transform hover:-translate-y-1 hover:shadow-lg ${pkg.popular ? 'relative -mt-4 z-10' : ''}`}
            >
              {pkg.popular && (
                <div className="absolute top-0 right-0 bg-accent text-white text-xs font-bold py-1 px-3 rounded-bl-lg">
                  Popular
                </div>
              )}
              <div className={`bg-primary text-white ${pkg.popular ? 'p-8' : 'p-6'} text-center`}>
                <h3 className="font-heading font-bold text-2xl mb-1">{pkg.name}</h3>
                <p className="opacity-80 text-sm">{pkg.subtitle}</p>
              </div>
              <div className="p-6">
                <div className="text-center mb-6">
                  <span className="text-3xl font-heading font-bold text-primary">{pkg.price}</span>
                  <span className="text-black">{pkg.period}</span>
                  {pkg.hours && <p className="text-sm text-black mt-1">{pkg.hours}</p>}
                </div>
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <i className={`fas ${feature.included ? 'fa-check text-accent' : 'fa-times text-muted'} mt-1 mr-3`}></i>
                      <span className={feature.included ? 'text-black' : 'text-muted'}>{feature.text}</span>
                    </li>
                  ))}
                </ul>
                <Button asChild variant={pkg.popular ? 'accent' : 'default'} className="w-full">
                  <a href="#contact">Get Started</a>
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-white rounded-xl p-8 shadow-custom">
          <h3 className="font-heading font-semibold text-2xl mb-6 text-center text-primary">Custom Solutions</h3>
          <p className="text-center text-black mb-6">
            Need something specific? I offer tailored solutions to meet your unique business requirements.
          </p>
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="flex items-start">
              <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl"></i>
              <div>
                <h4 className="font-heading font-medium text-lg mb-1">Project-Based Work</h4>
                <p className="text-sm text-black">Fixed price for defined projects</p>
              </div>
            </div>
            <div className="flex items-start">
              <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl"></i>
              <div>
                <h4 className="font-heading font-medium text-lg mb-1">Retainer Packages</h4>
                <p className="text-sm text-black">Guaranteed monthly availability</p>
              </div>
            </div>
            <div className="flex items-start">
              <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl"></i>
              <div>
                <h4 className="font-heading font-medium text-lg mb-1">Specialized Services</h4>
                <p className="text-sm text-black">Focused on specific business needs</p>
              </div>
            </div>
          </div>
          <div className="text-center">
            <Button asChild variant="muted">
              <a href="#contact">Contact for Custom Quote</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
