import { useState, useEffect } from "react";
import { portfolioItems } from "@/lib/utils";
import SectionHeader from "./SectionHeader";
import { Button } from "@/components/ui/button";

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [filteredItems, setFilteredItems] = useState(portfolioItems);
  const [isAnimating, setIsAnimating] = useState(false);
  
  // Get unique categories from portfolio items
  const uniqueCategories = Array.from(new Set(portfolioItems.map(item => item.category.toLowerCase())));
  const categories = ["all", ...uniqueCategories];
  
  useEffect(() => {
    setIsAnimating(true);
    
    const timer = setTimeout(() => {
      if (activeFilter === "all") {
        setFilteredItems(portfolioItems);
      } else {
        setFilteredItems(
          portfolioItems.filter(item => 
            item.category.toLowerCase() === activeFilter
          )
        );
      }
      
      setIsAnimating(false);
    }, 500); // Matches the animation duration
    
    return () => clearTimeout(timer);
  }, [activeFilter]);
  
  return (
    <section id="portfolio" className="py-16 md:py-24 bg-light">
      <div className="container mx-auto px-4">
        <SectionHeader
          title="Portfolio Samples"
          subtitle="Examples of my work and the results achieved"
        />
        
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((category, index) => (
            <Button
              key={index}
              variant={activeFilter === category ? "default" : "outline"}
              size="sm"
              className="capitalize"
              onClick={() => setActiveFilter(category)}
            >
              {category}
            </Button>
          ))}
        </div>
        
        <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-8 transition-opacity duration-500 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
          {filteredItems.length === 0 ? (
            <div className="col-span-full text-center py-10">
              <i className="fas fa-folder-open text-5xl text-gray-300 mb-4"></i>
              <p className="text-black text-xl">No projects found in this category</p>
            </div>
          ) : (
            filteredItems.map((item, index) => (
              <div 
                key={item.id} 
                className="bg-white rounded-xl shadow-custom overflow-hidden transition duration-300 transform hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="relative h-48 overflow-hidden group">
                  <img 
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-primary/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button className="bg-white text-primary rounded-full w-12 h-12 flex items-center justify-center transform -translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      <i className="fas fa-eye"></i>
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-heading font-semibold text-xl mb-2">{item.title}</h3>
                  <p className="text-black mb-4">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">{item.category}</span>
                    <button 
                      className="text-accent hover:text-primary transition flex items-center"
                      aria-label={`View details for ${item.title}`}
                    >
                      <span className="mr-1 text-sm">Details</span>
                      <i className="fas fa-arrow-right text-sm"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
